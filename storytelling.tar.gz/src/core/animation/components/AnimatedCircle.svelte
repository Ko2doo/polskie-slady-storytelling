<script lang="ts">
  import type { SvelteHTMLElements } from "svelte/elements";

  type Props = SvelteHTMLElements["svg"] & {
    strokeColor?: string;
    width?: number;
    height?: number;
    bodyId?: string;
  };

  let {
    strokeColor = "currentColor",
    width = 400,
    height = 360,
    bodyId = "circle-body",
    ...restProps
  }: Props = $props();
</script>

<svg {width} {height} viewBox="0 0 323 122" fill="none" xmlns="http://www.w3.org/2000/svg" {...restProps}>
  <path
    id={bodyId}
    d="M104.949 116.183C166.656 116.183 233.84 117.716 290.027 88.126C304.856 80.3167 328.08 66.3001 317.018 46.7787C310.034 34.455 294.652 27.5742 282.151 22.4133C260.055 13.291 236.175 8.32711 212.501 5.59546C164.023 0.0018785 108.109 0.906511 61.6323 17.409C44.3148 23.5579 -5.30282 40.159 3.54915 67.6985C10.977 90.8071 37.4833 101.942 59.007 107.323C100.065 117.587 144.111 117.968 186.167 119.136"
    stroke={strokeColor}
    stroke-width="5"
    stroke-linecap="round"
  />
</svg>
